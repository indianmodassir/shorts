const wave = document.querySelector(".wave");
let waves = 20;

while(waves--) {
  wave.append(
  document.createElement("div")
  );
}

function setWave() {
  wave.querySelectorAll("div")
  .forEach(function(el) {
    el.style.setProperty('--height',
    Math.floor(Math.random() * 50) + "px"
    );
  });
}
setInterval(setWave, 200);