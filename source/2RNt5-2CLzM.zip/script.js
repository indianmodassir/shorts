var drops = [], col;

function drawMatrix() {
  const canvas = document.querySelector("canvas");
  const ctx = canvas.getContext("2d");

  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  var text, matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
  font = 10,
  i = 0;

  col = canvas.width / font;
  for(i = 0; i < col; i++) drops[i] = 1;

  return function draw() {
    ctx.fillStyle = "#0000000a";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#f5f509";
    ctx.font = font + "px monospace";
    for(i = 0; i < drops.length; i++) {
      text = matrix[Math.floor(Math.random() * matrix.length)];
      ctx.fillText(text, i * font, drops[i] * font);
      if (drops[i] * font > canvas.height && Math.random() > 0.975)
      drops[i] = 0;
    drops[i]++;
  }
};
}

setInterval(drawMatrix(), 35);
window.addEventListener("resize", drawMatrix);