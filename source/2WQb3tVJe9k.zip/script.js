const output = document.querySelector("#output");
const editor = document.querySelector("#editor");

let activeTab = document.querySelector(".active"),
source = {};

document.querySelector(".tab").addEventListener("click", function(e) {
  let tab = e.target,
  tabName = tab.dataset.tab;

  tab.classList.add("active");

  // Deactivate previous active tab
  if (activeTab !== tab) {
    activeTab.classList.remove("active");
  }

  editor.value = source[tabName] || "";

  // Update active tab
  activeTab = tab;

  editor.hidden = !tabName;
  output.hidden = !editor.hidden;

  // Run final code if click run tab
  !tabName && runCode();
});

editor.addEventListener("input", function() {
  source[activeTab.dataset.tab] = this.value;
});

function runCode() {
  if (source.css) {
    output.contentDocument.head.innerHTML = `<style>${source.css}</style>`;
  }
  if (source.html) {
    output.contentDocument.body.innerHTML = source.html;
  }
  if (source.js) {
    output.contentWindow.eval(source.js);
  }
}