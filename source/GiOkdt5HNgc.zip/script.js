const screen = document.querySelector(".screen");

const buttons = [
  "AC", "←", "%", "÷",
  7, 8, 9, "×",
  4, 5, 6, "−",
  1, 2, 3,
  "+", "0",
  "00", ".", "="
];

buttons.forEach(function(val) {
  let res, btn = document.createElement("button");
  btn.textContent = val;

  btn.addEventListener("click", () => {
    res = screen.textContent;
    if (val === "AC") {
      screen.textContent = 0;
    }
    else if (val === "←") {
      screen.textContent = screen.textContent.slice(0, -1) || 0;
    }
    else if (val === "%" || val === "=") {
      doEval(val === "%" ? res + val : res);
    }
    else {
      res == 0 || res == "Error" ?
      screen.textContent = val :
      screen.textContent += val;
    }
  });
  document.querySelector(".buttons").append(btn);
});

function doEval(res) {
  let Math = {"%":"/100", "÷":"/", "×":"*", "−":"-"};
  try {
    screen.textContent = parseFloat(eval(
    res.replace(/[%÷×−]/g, (m) => Math[m])
    ).toFixed(8));
  } catch(e) {
    screen.textContent = "Error";
  }
}