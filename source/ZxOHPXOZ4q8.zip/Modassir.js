const listItems = document.querySelectorAll("li");

let draggedItem;

listItems.forEach(function (li) {
  li.addEventListener("dragstart", startDragHandler);
  li.addEventListener("dragover", dragOverHandler);
  li.addEventListener("drop", dropHandler);
  li.addEventListener("dragend", dragEndHandler);
});

function startDragHandler() {
  draggedItem = this;
}

function dragOverHandler(e) {
  e.preventDefault();
}

function dropHandler(e) {
  e.preventDefault();

  // Ignore drop if it's the same element
  if (this !== draggedItem) {
    const allItems = [].slice.call(document.querySelectorAll("li"));
    const targetIndex = allItems.indexOf(this);
    const dragIndex = allItems.indexOf(draggedItem);

    targetIndex > dragIndex ? this.after(draggedItem) : this.before(draggedItem);
  }
}

function dragEndHandler() {
  draggedItem = null;
}