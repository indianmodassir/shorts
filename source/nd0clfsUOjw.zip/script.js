for(let i = 1; i <= 12; i++) {
  document.querySelector(".watch").innerHTML += `<span class="i" style="--i:${i}"><span>${i}</span></span>`;
}

const hands = document.querySelectorAll(".h");
const date = document.querySelector(".date");

function startClock() {
  let dt = new Date(),
  m = dt.getMinutes(),
  s = dt.getSeconds(),
  h = 30 * dt.getHours() + m / 2;

  hands[0].style.rotate = `${h}deg`;
  hands[1].style.rotate = `${6 * m}deg`;
  hands[2].style.rotate = `${s * 6}deg`;

  date.textContent = dt.toLocaleDateString();
}

setInterval(startClock, 1000);
startClock();