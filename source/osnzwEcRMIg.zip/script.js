const scrollable = document.querySelector(".x-scrollable");

scrollable.addEventListener("wheel", (e) => {
  e.preventDefault();
  e.deltaY === 0 ? scrollable.scrollLeft += e.deltaX :
    scrollable.scrollLeft += e.deltaY;
  }, {passive: false});